async function api(action, data = {}) {
  const form = new FormData();
  form.append('action', action);
  for (const k in data) form.append(k, data[k]);

  const res = await fetch('', { method: 'POST', body: form });
  return res.json();
}

async function loadTasks() {
  const res = await api('list');
  const container = document.getElementById('tasksList');
  if (!res.success) { container.innerHTML = '<div class="text-danger">Erro ao carregar</div>'; return; }
  const tasks = res.tasks;
  if (tasks.length === 0) { container.innerHTML = '<div class="text-muted">Nenhuma tarefa encontrada.</div>'; return; }

  let html = '<div class="list-group">';
  for (const t of tasks) {
    const done = t.is_done == 1;
    html += `
      <div class="list-group-item d-flex justify-content-between align-items-start">
        <div>
          <div class="fw-bold ${done ? 'text-decoration-line-through text-muted' : ''}">${escapeHtml(t.title)}</div>
          <div class="small ${done ? 'text-muted' : ''}">${escapeHtml(t.description || '')}</div>
          <div class="small text-muted">Criado: ${t.created_at}</div>
        </div>
        <div class="btn-group btn-group-sm" role="group">
          <button class="btn btn-outline-success" onclick="toggle(${t.id}, ${done ? 0 : 1})">${done ? 'Reabrir' : 'Concluir'}</button>
          <button class="btn btn-outline-danger" onclick="remove(${t.id})">Excluir</button>
        </div>
      </div>
    `;
  }
  html += '</div>';
  container.innerHTML = html;
}

function escapeHtml(unsafe) {
  return unsafe
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

async function toggle(id, is_done) {
  await api('toggle', { id, is_done });
  loadTasks();
}

async function remove(id) {
  if (!confirm('Deseja realmente excluir esta tarefa?')) return;
  await api('delete', { id });
  loadTasks();
}

document.getElementById('taskForm').addEventListener('submit', async function (e) {
  e.preventDefault();
  const title = document.getElementById('title').value;
  const description = document.getElementById('description').value;
  const msg = document.getElementById('formMsg');
  msg.innerHTML = '';
  const res = await api('create', { title, description });
  if (res.success) {
    document.getElementById('taskForm').reset();
    msg.innerHTML = '<div class="text-success">Tarefa adicionada.</div>';
    loadTasks();
  } else {
    msg.innerHTML = `<div class="text-danger">${res.message || 'Erro'}</div>`;
  }
});

loadTasks();
<?php
header('Content-Type: text/html; charset=utf-8');
require_once __DIR__ . '/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json; charset=utf-8');
    $action = $_POST['action'];

    try {
        if ($action === 'create') {
            $title = trim($_POST['title'] ?? '');
            $description = trim($_POST['description'] ?? '');
            if ($title === '') {
                echo json_encode(['success' => false, 'message' => 'Título é obrigatório.']);
                exit;
            }
            $stmt = $pdo->prepare("INSERT INTO tasks (title, description) VALUES (:title, :description)");
            $stmt->execute([':title' => $title, ':description' => $description]);
            echo json_encode(['success' => true, 'id' => $pdo->lastInsertId()]);
            exit;
        }

        if ($action === 'list') {
            $stmt = $pdo->query("SELECT * FROM tasks ORDER BY created_at DESC");
            $tasks = $stmt->fetchAll();
            echo json_encode(['success' => true, 'tasks' => $tasks]);
            exit;
        }

        if ($action === 'toggle') {
            $id = (int)($_POST['id'] ?? 0);
            $is_done = (int)($_POST['is_done'] ?? 0);
            $stmt = $pdo->prepare("UPDATE tasks SET is_done = :is_done WHERE id = :id");
            $stmt->execute([':is_done' => $is_done, ':id' => $id]);
            echo json_encode(['success' => true]);
            exit;
        }

        if ($action === 'delete') {
            $id = (int)($_POST['id'] ?? 0);
            $stmt = $pdo->prepare("DELETE FROM tasks WHERE id = :id");
            $stmt->execute([':id' => $id]);
            echo json_encode(['success' => true]);
            exit;
        }

        echo json_encode(['success' => false, 'message' => 'Ação desconhecida.']);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}
?>
<!doctype html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>To-Do List - Tarefas</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/custom.css">
</head>
<body class="bg-light">

<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">To-Do</a>
  </div>
</nav>

<div class="container my-4">
  <div class="row">
    <div class="col-lg-4">
      <div class="card shadow-sm">
        <div class="card-header">Nova Tarefa</div>
        <div class="card-body">
          <form id="taskForm">
            <div class="mb-3">
              <label for="title" class="form-label">Título</label>
              <input type="text" class="form-control" id="title" name="title" required>
            </div>
            <div class="mb-3">
              <label for="description" class="form-label">Descrição</label>
              <textarea class="form-control" id="description" name="description" rows="3"></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Salvar</button>
            <div id="formMsg" class="mt-2"></div>
          </form>
        </div>
      </div>
      <div class="mt-3 text-muted small">Layout inspirado no AdminLTE.</div>
    </div>

<div class="col-lg-8">
<div class="card shadow-sm">
<div class="card-header">Minhas Tarefas</div>
<div class="card-body">
<div id="tasksList">Carregando...</div>
</div>
</div>
</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/app.js"></script>
</body>
</html>
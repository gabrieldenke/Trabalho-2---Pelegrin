<?php
// db.php - conexão PDO e criação de banco/tabela automática

// Ajuste estas credenciais conforme seu ambiente
$dbHost = '127.0.0.1';
$dbUser = 'root';
$dbPass = '';
$dbName = 'todo_app';
$charset = 'utf8mb4';

$dsnWithoutDb = "mysql:host={$dbHost};charset={$charset}";
$dsnWithDb = "mysql:host={$dbHost};dbname={$dbName};charset={$charset}";
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
];

try {
    $pdo = new PDO($dsnWithoutDb, $dbUser, $dbPass, $options);
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$dbName}` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci");
    $pdo = new PDO($dsnWithDb, $dbUser, $dbPass, $options);

    $createTableSql = "
    CREATE TABLE IF NOT EXISTS tasks (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        description TEXT,
        is_done TINYINT(1) NOT NULL DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ";
    $pdo->exec($createTableSql);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Erro ao conectar ao banco: ' . $e->getMessage()]);
    exit;
}
?>